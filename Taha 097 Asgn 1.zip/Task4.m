dice_roll = randi(6);
fprintf('Dice Roll: %d\n', dice_roll);


coin_toss = randi([0,1]);
if coin_toss == 0
    disp('Coin Toss: Heads');
else
    disp('Coin Toss: Tails');
end
