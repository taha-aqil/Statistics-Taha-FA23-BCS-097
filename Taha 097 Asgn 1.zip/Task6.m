n = 8; r = 5;
permutation = factorial(n) / factorial(n-r);
combination = factorial(n) / (factorial(r) * factorial(n-r));

fprintf('Permutation P(%d,%d) = %d\n', n, r, permutation);
fprintf('Combination C(%d,%d) = %d\n', n, r, combination);
