spam = 0.7;       
notspam = 0.3;  
word_spam = 0.7;
word_notspam = 0.1;
word = (word_spam * spam) + (word_notspam * notspam);

spam_given_word = (word_spam * spam) / word;
fprintf('The probability that an email is spam given it has the given word = %.2f\n', spam_given_word);
