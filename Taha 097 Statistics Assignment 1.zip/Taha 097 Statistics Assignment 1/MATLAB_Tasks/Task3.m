data = [9 5 7 8 5 6 9 4 8 5 6 9];  
histogram(data);

