data = readmatrix('task1data.csv'); 
disp('Imported dataset:');
disp(data);
