lottery_numbers = randperm(49, 6);
disp('Lottery Numbers:');
disp(lottery_numbers);
