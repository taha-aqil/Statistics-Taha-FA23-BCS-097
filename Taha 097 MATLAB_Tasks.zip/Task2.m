data = [5, 10, 15, 20, 25];
mean_val = mean(data);
var_val = var(data);
fprintf('Mean = %.2f\n', mean_val);
fprintf('Variance = %.2f\n', var_val);

